package covid;
//Mar�a Peinado Toledo. Doble Grado Ingenier�a Inform�tica y Matem�ticas. Grupo A
import java.util.Set;

public interface InfoCOVID {
	public Set<String> obtenerInfo(MapaCOVID mapa);
}
