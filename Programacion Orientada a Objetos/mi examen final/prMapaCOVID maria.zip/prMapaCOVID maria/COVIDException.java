package covid;
//Mar�a Peinado Toledo. Doble Grado Ingenier�a Inform�tica y Matem�ticas. Grupo A
@SuppressWarnings("serial")
public class COVIDException extends RuntimeException{
	public COVIDException() {
		super();
	}
	public COVIDException(String msg) {
		super(msg);
	}
}
