package regata;

public class RegataException extends RuntimeException {
	public RegataException() {
		super();
	}
	public RegataException(String msg) {
		super(msg);
	}
}
