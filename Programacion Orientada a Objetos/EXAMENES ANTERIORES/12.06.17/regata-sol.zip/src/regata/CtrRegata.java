package regata;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;

public class CtrRegata implements ActionListener {
	private Regata regata;
	private VistaRegata vistaRegata;

	public CtrRegata(VistaRegata vistaRegata) {
		this.vistaRegata = vistaRegata;
	}

	public void actionPerformed(ActionEvent event) {
		String comando = event.getActionCommand();
		try {
			switch (comando) {
			case VistaRegata.LEE:
				regata = new Regata();
				String fichero = vistaRegata.getFicheroEntrada();
				regata.leeFichero(fichero);
				vistaRegata.limpiaPantalla();
				for (Barco b : regata.getParticipantes()) {
					vistaRegata.agregaLinea(b.toString());
				}
				vistaRegata.setMensaje("Fichero leido");
				break;
			case VistaRegata.GUARDA:
				fichero = vistaRegata.getFicheroSalida();
				regata.escribeFichero(fichero);
				vistaRegata.setMensaje("Fichero guardado");
				break;
			case VistaRegata.AVANZA:
				regata.avanza(10);
				vistaRegata.limpiaPantalla();
				for (Barco b : regata.getParticipantes()) {
					vistaRegata.agregaLinea(b.toString());
				}
				vistaRegata.setMensaje("Avanza con exito");
			}
		} catch (FileNotFoundException e) {
			vistaRegata.limpiaPantalla();
			vistaRegata.setMensaje("Error en el fichero");
		} catch (RegataException e) {
			vistaRegata.limpiaPantalla();
			vistaRegata.setMensaje(e.getMessage());
		} catch (NullPointerException e) {
			vistaRegata.limpiaPantalla();
			vistaRegata.setMensaje("aún no se ha creado ninguna regata");
		}
	}
}
