package regata;

public class Barco implements Comparable<Barco> {
	protected String nombre;
	protected Posicion posicion;
	protected int rumbo;
	protected int velocidad;
	
	public Barco(String n, Posicion p, int r, int v) {
		nombre = n;
		posicion = p;
		if (rumbo>=360 || rumbo < 0) {
			throw new RegataException("Rumbo incorrecto "+ rumbo);
		}
		rumbo = r;
		velocidad = v;
	}

	public String getNombre() {
		return nombre;
	}

	public Posicion getPosicion() {
		return posicion;
	}

	public int getRumbo() {
		return rumbo;
	}

	public int getVelocidad() {
		return velocidad;
	}

	@Override 
	public String toString() {
		return nombre + ": " + posicion + " R= "+ rumbo+ " V= " + velocidad;
	}
	
	@Override
	public boolean equals(Object object) {
		boolean res = object instanceof Barco;
		Barco barco = res?(Barco)object: null;
		return res && nombre.equalsIgnoreCase(barco.nombre);
	}
	
	@Override
	public int hashCode() {
		return nombre.toUpperCase().hashCode();
	}
	
	@Override 
	public int compareTo(Barco barco) {
		return nombre.compareToIgnoreCase(barco.nombre);
	}
	
	public void avanza(int mnt) {
		posicion = posicion.posicionTrasRecorrer(mnt, rumbo, velocidad);	
	}
}
