package regata;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class Regata {
	private Set<Barco> participantes;
	
	public Regata() {
		participantes = new TreeSet<>(); 
	}
		
	public void agrega(Barco b) {
		participantes.add(b);
	}
	
	public boolean velocidadSuperiorA(int velocidad) {
		Iterator< Barco> it = participantes.iterator();
		while (it.hasNext() && it.next().getVelocidad() < velocidad) {
		}
		return it.hasNext();
	}
	
	public List<Barco> dentroDelCirculo(Posicion p, int km) {
		List<Barco> barcos = new ArrayList<>(); 
		for(Barco b : participantes) {
			if (b.getPosicion().distancia(p) < km) {
				barcos.add(b);
			}
		}
		return barcos;
	}
	
	public Map<Integer, Set<Barco>> barcosPorVelocidad() {
		Map<Integer, Set<Barco>> map = new TreeMap<>();
		for(Barco b: participantes) {
			int v = b.getVelocidad()/10;
			Set<Barco> set = map.get(v);
			if (set == null) {
				set = new TreeSet<>();
				map.put(v, set);
			}
			set.add(b);
		}
		return map;
	}
		
	public void avanza(int mnt) {
		for(Barco b : participantes) {
			b.avanza(mnt);
		}
	}
	
	public Set<Barco> getParticipantes() {
		return participantes;
	}
	
	public Set<Barco> ordenadosPorDistancia() {
		Set<Barco> set = new TreeSet<>(new SatBarco());
		set.addAll(participantes);
		return set;
	}
	
	public Barco creaBarcoString(String dato) {
		try (Scanner sc = new Scanner(dato)) {
			sc.useDelimiter("[ ,]+");
			String nombre = sc.next();
			double lat = sc.nextDouble();
			double lon = sc.nextDouble();
			Posicion posicion = new Posicion(lat, lon);
			int rumbo = sc.nextInt();
			int velocidad = sc.nextInt();
			return new Barco(nombre, posicion, rumbo, velocidad);
		} catch (InputMismatchException e) {
			throw new RegataException("Algun dato numerico es erroneo en " + dato);
		} catch (NoSuchElementException e) {
			throw new RegataException("Faltan datos  en " + dato);			
		}
	}
	
	public void leeFichero(String nFichero) throws FileNotFoundException {
		try (Scanner scanner = new Scanner(new File(nFichero))) {
			lee(scanner);
		}
	}
	
	public void lee(Scanner sc) {
		while (sc.hasNextLine()) {
			agrega(creaBarcoString(sc.nextLine()));
		}
	}
	
	public void escribeFichero(String nFichero) throws FileNotFoundException {
		try (PrintWriter printWriter = new PrintWriter(nFichero)) {
			escribe(printWriter);
		}
	}
	
	public void escribe(PrintWriter pw) {
		for (Barco b: participantes) {
			pw.println(b);
		}
	}
 }

