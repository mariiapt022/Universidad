package regata;

public class Posicion {
	private double longitud;
	private double latitud;
	private static final double  mToKm= 1.60934;
	/**
	 * Crea una posicion
	 * @param lat  	latitud
	 * @param lon	longitud
	 */
	public Posicion(double lat, double lon) {
		latitud = normalizaLat(lat);
		longitud = normalizaLon(lon);
	}
	
	/**
	 * Devuelve la latitud
	 * @return la latitud
	 */
	public double getLatitud() {
		return latitud;
	}
	
	/**
	 * Devuelve la longitud
	 * @return la longitud
	 */
	public double getLongitud() {
		return longitud;
	}
		
	/**
	 * Normaliza una latitud
	 * @param lat latitud no normalizada
	 * @return latitud normalizada
	 */
	private double normalizaLat(double lat) {
		double res = lat % 360;
		if (res < 0) {
			res = res + 360;
		}
		// Ya es un numero entre 0 y 360
		if (res > 90 && res <= 270) {
			res = 180 - res;
		} else if (res > 270 && res < 360) {
			res = res - 360;
		}
		return res;
	}
	
	/**
	 * Normaliza la longitud
	 * @param lon longitud no normalizada
	 * @return longitud normalizada
	 */
	private double normalizaLon(double lon) {
		double res = lon % 360;
		if (res < 0) {
			res += 360;
		}
		return res;
	}
	
	@Override
	public String toString() {
		return String.format("l= %4.2f L= %4.2f", latitud, longitud);
	}
	
	/**
	 * Calcula la distancia entre el receptor y una posicion
	 * @param p posicion
	 * @return la distancia en km
	 */
	public double distancia(Posicion p) {
        double incrl = (p.latitud - latitud)*60; // incremento de longitud en millas
        double incrL = (p.longitud - longitud)*60; // incremento de latitud en millas
        double lm = (latitud + p.latitud)/2; // longitud media del trayecto
        double apartamiento = incrL*Math.cos(Math.toRadians(lm)); // Apartamiento en millas
        return Math.sqrt(Math.pow(apartamiento, 2)+ Math.pow(incrl, 2));	 // Distancia
	}
	
	/**
	 * Posicion final si se parte de la posicion receptora y se avanza 
	 * los minutos dados en el rumbo y velocidad dados
	 * @param minutos	Minutos que se van a avanzar
	 * @param rumbo		Rumbo en el que se avanza
	 * @param velocidad	Velocidad a la que se avanza (km/h)
	 * @return Posicion a la que se llega
	 */
	public Posicion posicionTrasRecorrer(int minutos, int rumbo, int velocidad) {
        /*
         *
         *               A
         *           ---------           ---------
         *           |       /           |       /
         *           |      /            |      /
         *           |     /             |     /
         *           |    / D          A |    / incrL
         *     incrl |   /               |   /
         *           |  /                |lm/
         *           |R/                 | /
         *           |/                  |/
         *
         *   A = Apartamiento (millas)
         *   D = Distancia Recorrida (millas)
         *   R = Rumbo (grados)
         *   incrl = incremento de longitud (millas)
         *   incrL = incremento de latitud (millas)
         *   lm = longitud media del trayecto (grados)
         *
         *   ** Loxodromica Directa
         *   Se conoce:
         *     - Posicion de salida (ls,Ls)
         *     - Rumbo
         *     - Distancia recorrida
         *   Se pide
         *     - Posicion de llegada (lf,Lf)
         *   Solucion
         *     A = D * sin R
         *     incrl = D * cos R
         *     lm = ls + incrl/2
         *     incrL = A / cos lm
         *     lf = ls + incrl
         *     Lf = Ls + incrL
         *
         *   ** Loxodromica Inversa
         *   Se conoce
         *     - Posicion de salida (ls, Ls)
         *     - Posicion de llegada (lf, Lf)
         *   Se pide
         *     - Rumbo
         *     - Distancia
         *   Solucion
         *     incrl = lf - ls (en millas)
         *     incrL = Lf - Ls (en millas)
         *     lm = (ls + lf) / 2
         *     A = incrL * cos lm  (en millas)
         *     D = raiz( A*A + incrl*incrl)
         *     R = atan(A/incrl)
         *
         */
        double rumboRad = Math.toRadians(rumbo); // Rumbo en radianes
        double distanciaMillas = (velocidad/1.60934)*minutos/60; // distancia en millas
        double apartamiento = distanciaMillas*Math.sin(rumboRad); // apartamiento en millas
        double incrl = distanciaMillas*Math.cos(rumboRad)/60; // incremento de logitud en grados
        double lm = latitud + incrl/2; // longitud media del trayecto
        double incrL = apartamiento/Math.cos(Math.toRadians(lm))/60; // incremento de latitud en grados
        return new Posicion(latitud+incrl, longitud+incrL);	// nueva posicion	
	}
}
