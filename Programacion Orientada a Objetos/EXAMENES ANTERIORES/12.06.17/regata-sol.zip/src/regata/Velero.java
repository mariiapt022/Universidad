package regata;

public class Velero extends Barco {
	public Velero(String n, Posicion p, int r, int v) {
		super(n, p, r, v);
	}
	
	@Override	
	public void avanza(int mnt) {
		if (rumbo <= 45 || rumbo >= 315 ) {
			posicion = posicion.posicionTrasRecorrer(mnt, rumbo, velocidad-3);	
		} else if (rumbo >= 135 && rumbo <= 225){
			posicion = posicion.posicionTrasRecorrer(mnt, rumbo, velocidad+3);	
		} else {
			super.avanza(mnt);
		}
	}

}
