import java.util.Arrays;

import regata.Barco;
import regata.Posicion;

public class Main1 {
	public static void main(String [] args) {
		Barco[] barcos = {
				new Barco("alisa", new Posicion(340,  -120), 80,  20),
				new Barco("vera", new Posicion(-30,  290), 20,  25),
				new Barco("kamira", new Posicion(400,  182), 230,  33),
				new Barco("gamonal", new Posicion(-390,  -190), 0,  24),			
		};

		Arrays.sort(barcos);
		System.out.println(barcos[0]);
		System.out.println(barcos[barcos.length-1]);
		
	}
}
