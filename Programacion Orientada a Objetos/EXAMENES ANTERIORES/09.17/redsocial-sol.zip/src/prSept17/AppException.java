
package prSept17;

public class AppException extends RuntimeException {
    public AppException() {
		super();
    }
    public AppException(String m) {
		super(m);
    }
}
