
package prSept17;

import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;

public class CuentaModerada extends Cuenta {
    private Set<String> claves;

    public CuentaModerada(String usr, Set<String> c) {
		super(usr);
		if (c == null) {
			throw new AppException("BadArgs");
		}
		claves = new HashSet<String>();
		for (String x : c) {
			claves.add(x.toUpperCase());
		}
    }
    public void addMsj(String receptor, String txt) {
		boolean ok = false;
		String texto = txt.toUpperCase();
		Iterator<String> it = claves.iterator();
		while ( ! ok && it.hasNext() ) {
			ok = texto.contains(it.next());
		}
		if (ok) {
			throw new AppException("BadText");
		}
		super.addMsj(receptor, txt);
    }
}
