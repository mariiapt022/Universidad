
package prSept17;

import java.io.IOException;
import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

public class RedSocial {
    private String usuarioActivo;
    private SortedMap<String,Cuenta> cuentas;
    public RedSocial() {
		usuarioActivo = null;
		cuentas = new TreeMap<String,Cuenta>();
		cuentas.put("ADMIN", new Cuenta("ADMIN"));
    }
    public void login (String usr) {
		// *Simplificado*
		if (/*(usuarioActivo != null && usuarioActivo.length() > 0)
			|| usr == null || usr.length() == 0
			||*/ cuentas.get(usr.toUpperCase()) == null) {
			throw new AppException("BadArgs");
		}
		usuarioActivo = usr.toUpperCase();
    }
    public void logout() {
		usuarioActivo = null;
    }
    public void crearCuenta(String usr) {
		// *Simplificado*
		if (usuarioActivo == null || ! usuarioActivo.equals("ADMIN")
			/*|| usr == null || usr.length() == 0*/
			|| cuentas.get(usr.toUpperCase()) != null) {
			throw new AppException("BadArgs");
		}
		cuentas.put(usr.toUpperCase(), new Cuenta(usr.toUpperCase()));
    }
    public void addMsj(String receptor, String txt) {
		// *Simplificado*
		//if (usuarioActivo == null || usuarioActivo.length() == 0
		//	|| receptor == null || receptor.length() == 0
		//	|| txt == null || txt.length() == 0) {
		//	throw new AppException("BadArgs");
		//}
		Cuenta c = cuentas.get(usuarioActivo);
		c.addMsj(receptor, txt);
    }
    public SortedSet<Mensaje> getMsjsCon(String usuario) {
		// *Simplificado*
		if (/*usuarioActivo == null || usuarioActivo.length() == 0
			|| usuario == null || usuario.length() == 0
			||*/ cuentas.get(usuario.toUpperCase()) == null) {
			throw new AppException("BadArgs");
		}
		Filtro filtro1 = new FiltroReceptor(usuarioActivo);
		Filtro filtro2 = new FiltroReceptor(usuario);
		SortedSet<Mensaje> m = new TreeSet<Mensaje>();
		m.addAll(cuentas.get(usuario.toUpperCase()).getMsjs(filtro1));
		m.addAll(cuentas.get(usuarioActivo.toUpperCase()).getMsjs(filtro2));
		return m;
    }
    public SortedSet<Mensaje> getMsjsClaves(Set<String> c) {
		// *Simplificado*
		//if (usuarioActivo == null || usuarioActivo.length() == 0 ) {
		//	throw new AppException("BadArgs");
		//}
		Filtro filtro = new FiltroTexto(c);
		SortedSet<Mensaje> m = new TreeSet<Mensaje>();
		m.addAll(cuentas.get(usuarioActivo).getMsjs(filtro));
		return m;
    }
	// *Simplificado*
    //public void removeMsjsA (String receptor) {
	//	if (usuarioActivo == null || usuarioActivo.length() == 0
	//		|| receptor == null || receptor.length() == 0) {
	//		throw new AppException("BadArgs");
	//	}
	//	Filtro filtro = new FiltroReceptor(receptor);
	//	cuentas.get(usuarioActivo).removeMsjs(filtro);
    //}
	// *Simplificado*
	//public void removeMsjsClaves(Set<String> c) {
	//	if (usuarioActivo == null || usuarioActivo.length() == 0) {
	//		throw new AppException("BadArgs");
	//	}
	//	Filtro filtro = new FiltroTexto(c);
	//	cuentas.get(usuarioActivo).removeMsjs(filtro);
	//}
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("{");
		for (Map.Entry<String,Cuenta> e : cuentas.entrySet()) {
			sb.append(" ");
			sb.append(e.getKey());
			sb.append(": ");
			sb.append(e.getValue());
		}
		sb.append(" }");
		return sb.toString();
	}
	public void crearCuentaModerada(String usr, Set<String> c) {
		// *Simplificado*
		if (usuarioActivo == null || ! usuarioActivo.equals("ADMIN")
			/*|| usr == null || usr.length() == 0*/
			|| cuentas.get(usr.toUpperCase()) != null) {
			throw new AppException("BadArgs");
		}
		cuentas.put(usr.toUpperCase(), new CuentaModerada(usr.toUpperCase(), c));
	}
	private void nuevoMensaje(String e, String r, String t)  {
		Cuenta c = cuentas.get(e.toUpperCase());
		if (c == null) {
			c = new Cuenta(e.toUpperCase());
			cuentas.put(c.getUsuario(), c);
		}
		c.addMsj(r, t);
	}
    public void cargarDeFichero(String n) throws IOException {
		try (Scanner sc = new Scanner(new File(n))) {
			while (sc.hasNextLine()) {
				String linea = sc.nextLine();
				String[] campos = linea.split("\\s*[;]\\s*", 3);
				this.nuevoMensaje(campos[0], campos[1], campos[2]);
			}
		} catch (IndexOutOfBoundsException e) {
			throw new AppException(e.getMessage());
		}
    }
    public void guardarEnFichero(String n) throws IOException {
		SortedSet<Mensaje> setMsj = new TreeSet<Mensaje>();
		for (Cuenta c : cuentas.values()) {
			setMsj.addAll(c.getMsjs(null));
		}
		try (PrintWriter pw = new PrintWriter(n)) {
			for (Mensaje m : setMsj) {
				pw.println(m.getEmisor() + " ; "
						   + m.getReceptor() + " ; "
						   + m.getTexto() );
			}
		}
    }
}
