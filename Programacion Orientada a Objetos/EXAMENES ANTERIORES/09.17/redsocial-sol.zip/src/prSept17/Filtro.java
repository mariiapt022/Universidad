
package prSept17;

public interface Filtro {
    boolean select(Mensaje m);
}
