
package prSept17;

import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;

public class FiltroTexto  implements Filtro {
    private Set<String> claves;
    public FiltroTexto(Set<String> c) {
		claves = new HashSet<String>();
		if (c != null) {
			for (String x : c) {
				claves.add(x.toUpperCase());
			}
		}
    }
    public boolean select(Mensaje m) {
		boolean ok = false;
		String txt = m.getTexto().toUpperCase();
		Iterator<String> it = claves.iterator();
		while ( ! ok && it.hasNext() ) {
			ok = txt.contains(it.next());
		}
		return ok;
    }
}
