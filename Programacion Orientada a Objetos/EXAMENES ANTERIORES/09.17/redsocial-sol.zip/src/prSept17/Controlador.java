
package prSept17;

import java.util.Set;
import java.io.IOException;

import java.awt.event.*;

public class Controlador implements ActionListener {
	private Vista vista;
	private RedSocial modelo;
	public Controlador(Vista v, RedSocial m) {
		vista = v;
		modelo = m;
		vista.activarInteraccion(false);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		try {
			switch (e.getActionCommand()) {
			case Vista.LOGIN:		login();		break;
			case Vista.LOGOUT:		logout();		break;
			case Vista.CREARCNT:	crearcnt();		break;
			case Vista.ENVMSJ:		envmsj();		break;
			case Vista.LEERMSJ:		leermsj();			break;
			case Vista.CARGARFICH:	cargarfich();	break;
			case Vista.GUARDARFICH:	guardarfich();	break;
			}
		} catch (Exception ex) {
			vista.setLineaEstado("Operacion Erronea");
		}
	}
	private void login() {
		String usr = vista.getLogin();
		modelo.login(usr);
		vista.setLogin(usr);
		vista.activarInteraccion(true);
		vista.setLineaEstado("Operacion Correcta");
	}
	private void logout() {
		modelo.logout();
		vista.setLogin("");
		vista.cleanMensajes();
		vista.activarInteraccion(false);
		vista.setLineaEstado("Operacion Correcta");
	}
	private void crearcnt() {
		String usr = vista.getNuevoUsuario();
		Set<String> blk = vista.getClvBloqueo();
		if (blk != null && blk.size() > 0) {
			modelo.crearCuentaModerada(usr, blk);
		} else {
			modelo.crearCuenta(usr);
		}
		vista.setLineaEstado("Operacion Correcta");
	}
	private void envmsj() {
		String rcp = vista.getReceptorMsj();
		String txt = vista.getTextoMsj();
		modelo.addMsj(rcp, txt);
		vista.setLineaEstado("Operacion Correcta");
	}
	private void leermsj() {
		String usr = vista.getUsuarioMsj();
		Set<String> clv = vista.getClvMsj();
		if (usr != null && usr.length() > 0) {
			this.mostrarMensajes(modelo.getMsjsCon(usr));
		} else if (clv != null && clv.size() > 0) {
			this.mostrarMensajes(modelo.getMsjsClaves(clv));
		} else {
			vista.setLineaEstado("Operacion Erronea");
		}
	}
	private void mostrarMensajes(Set<Mensaje> msg) {
		vista.cleanMensajes();
		for (Mensaje m : msg) {
			vista.addMensaje(m.toString());
		}
		vista.setLineaEstado("Operacion Correcta");
	}
	private void cargarfich() throws IOException {
		String nfich =  vista.getNombreFichero();
		modelo.cargarDeFichero(nfich);
		vista.setLineaEstado("Operacion Correcta");
	}
	private void guardarfich() throws IOException {
		String nfich =  vista.getNombreFichero();
		modelo.guardarEnFichero(nfich);
		vista.setLineaEstado("Operacion Correcta");
	}
}
