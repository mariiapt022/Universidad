
package prSept17;

public class Mensaje implements Comparable<Mensaje> {
    private static int cntSecuencia = 1;
    private int secuencia;
    private String emisor;
    private String receptor;
    private String texto;
	
    public Mensaje(String e, String r, String txt) {
		if (e == null || e.length() == 0
			|| r == null || r.length() == 0
			|| txt == null || txt.length() == 0) {
			throw new AppException("BadArgs");
		}
		emisor = e;
		receptor = r;
		texto = txt;
		secuencia = cntSecuencia;
		++cntSecuencia;
    }
    public String getEmisor() {
		return emisor;
    }
    public String getReceptor() {
		return receptor;
    }
    public String getTexto() {
		return texto;
    }
	@Override
    public String toString() {
		return "(" + emisor + "; " + receptor + "; " + texto + ")";
    }
	@Override
    public boolean equals(Object o) {
		boolean ok = false;
		if (o instanceof Mensaje) {
			Mensaje x = (Mensaje)o;
			ok = (this.secuencia == x.secuencia)
				&& (this.emisor.equalsIgnoreCase(x.emisor))
				&& (this.receptor.equalsIgnoreCase(x.receptor));
		}
		return ok;
    }
	@Override
    public int hashCode() {
		return secuencia // Integer.hashCode(secuencia)
			+ emisor.toUpperCase().hashCode()
			+ receptor.toUpperCase().hashCode();
    }
	@Override
    public int compareTo(Mensaje m) {
		int x = Integer.compare(this.secuencia, m.secuencia);
		if (x == 0) {
			x = this.emisor.compareToIgnoreCase(m.emisor);
			if (x == 0) {
				x = this.receptor.compareToIgnoreCase(m.receptor);
			}
		}
		return x;
    }
}
