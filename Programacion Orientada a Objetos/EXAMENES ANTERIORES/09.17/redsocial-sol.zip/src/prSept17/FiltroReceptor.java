
package prSept17;

public class FiltroReceptor implements Filtro {
    private String receptor;
    public FiltroReceptor (String r) {
		receptor = r;
    }
    public boolean select (Mensaje m) {
		return m != null && m.getReceptor().equalsIgnoreCase(receptor);
    }
}
