
package prSept17;

import java.util.SortedSet;
import java.util.TreeSet;
import java.util.Iterator;

public class Cuenta {
    private String usuario;
    private SortedSet<Mensaje> mensajes;
    public Cuenta (String usr) {
		if (usr == null || usr.length() == 0) {
			throw new AppException("BadArgs");
		}
		usuario = usr;
		mensajes = new TreeSet<Mensaje>();
    }
    public String getUsuario() {
		return usuario;
    }
    public void addMsj(String receptor, String txt) {
		// *Simplificado*
		//if (receptor == null || receptor.length() == 0
		//	|| txt == null || txt.length() == 0) {
		//	throw new AppException("BadArgs");
		//}
		mensajes.add(new Mensaje(usuario, receptor, txt));
    }
    public SortedSet<Mensaje> getMsjs(Filtro flt) {
		SortedSet<Mensaje> s = new TreeSet<Mensaje>();
		if (flt == null) {
			s.addAll(mensajes);
		} else {
			for (Mensaje m : mensajes) {
				if (flt.select(m)) {
					s.add(m);
				}
			}
		}
		return s;
    }
	// *Simplificado*
    //public void removeMsjs(Filtro flt) {
	//	if (flt == null) {
	//		mensajes.clear();
	//	} else {
	//		Iterator<Mensaje> it = mensajes.iterator();
	//		while (it.hasNext()) {
	//			if (flt.select(it.next())) {
	//				it.remove();
	//			}
	//		}
	//	}
    //}
	@Override
    public String toString() {
		return mensajes.toString();
    }
}
