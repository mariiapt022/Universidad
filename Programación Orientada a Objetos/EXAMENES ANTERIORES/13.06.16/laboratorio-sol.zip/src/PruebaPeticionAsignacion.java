import prExJunio2016.AsignacionException;
import prExJunio2016.FranjaHoraria;
import prExJunio2016.PeticionAsignacion;

public class PruebaPeticionAsignacion {
	public static void main(String [] args)  {
		try {
		PeticionAsignacion pa1 = new PeticionAsignacion("Juan Lopez", "POO", new FranjaHoraria("LUNES", "PRIMERA"));
		PeticionAsignacion pa2 = new PeticionAsignacion("Maria Gomez", "FP", new FranjaHoraria("LUNES", "PRIMERA"));
		System.out.println(pa1);
		System.out.println(pa2);
		if (pa1.equals(pa2)) {
			System.out.println("Conflicto LUNES a PRIMERA hora");
		}
		} catch (AsignacionException e) {
			System.out.println("Error: Franja Horaria Incorrecta");
		}
	}
}
