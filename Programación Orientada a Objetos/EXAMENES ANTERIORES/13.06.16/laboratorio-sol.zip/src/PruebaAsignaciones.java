import java.io.FileNotFoundException;

import prExJunio2016.Asignaciones;
import prExJunio2016.FranjaHoraria;

public class PruebaAsignaciones {
	public static void main(String [] args) throws FileNotFoundException {
		Asignaciones as = new Asignaciones(2);
		as.leerPeticionesDesdeFichero("peticiones.txt");
		System.out.println(as);
		System.out.println("Laboratorios libres los jueves a cuarta hora " +as.buscarHuecos(new FranjaHoraria("JUEVES", "CUARTA")));
	}
}
