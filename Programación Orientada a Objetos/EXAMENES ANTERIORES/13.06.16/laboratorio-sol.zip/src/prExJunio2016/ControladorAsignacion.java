package prExJunio2016;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;

public class ControladorAsignacion implements ActionListener {
	private VistaAsignacion vista;
	private Asignaciones asignacion;

	public ControladorAsignacion(VistaAsignacion v) {
		vista = v;
		vista.habilitarInicio(true);
		vista.mensaje("Rellenar y pulsar iniciar");
	}

	public void actionPerformed(ActionEvent event) {
		String comando = event.getActionCommand();
		vista.mensaje(" "); // borra cualquier mensaje previo
		vista.error(" "); // borra cualquier mensaje previo
		try {
			switch (comando) {
			case VistaAsignacion.INICIO:
				boolean  alt = vista.conAlternativas();
				String nfp = vista.fichPeticiones();
				int lab = vista.laboratorios();
				if (lab <= 0) {
					throw new AsignacionException("Laboratorios no positivos");
				} 
				if (nfp.equals("")) {
					throw new AsignacionException("Peticion no existe");
				}
				if (!alt) {
					asignacion = new Asignaciones(lab, nfp);
				} else {
					asignacion = new AsignacionesConAlternativas(lab, nfp);
				}
				vista.habilitarInicio(false);
				vista.entradaHistorial(asignacion.toString());
				vista.mensaje("Operacion realizada");
				break;
			case VistaAsignacion.GUARDAR:
				String fichSalida = vista.fichSalida();
				asignacion.escribirAFichero(fichSalida);
				vista.mensaje("Guardado");
				break;
			case VistaAsignacion.REINICIO:
				vista.habilitarInicio(true);
				vista.limpiarHistorial();
			/*
			 * case VistaAsignacion.ELIM_CONFLICTOS:
			 * Map<String,List<FranjaHoraria>> map =
			 * vista.horariosAsignaturas(); try {
			 * asignacion.eliminarConflictos(map);
			 * vista.entradaHistorial(asignacion.toString()); vista.mensaje(
			 * "eliminados los conflictos"); } catch (AsignacionException e) {
			 * vista.error("Problema al eliminar conflictos"); }
			 */
			}
		} catch (AsignacionException e) {
			vista.error("Error: " + e.getMessage());
		} catch (FileNotFoundException e) {
			vista.error("No existe el fichero " + e.getMessage());
		}
	}
}
