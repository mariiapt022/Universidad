package prExJunio2016;

import java.io.File;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

public class Asignaciones {
	private SortedMap<Integer, SortedSet<PeticionAsignacion>> asignaciones;
	protected List<PeticionAsignacion> conflictos;
	private final int NUM_LAB;
	
	public Asignaciones(int lab) {
		NUM_LAB = lab;
		asignaciones = new TreeMap<>();
		conflictos = new ArrayList<>();
		for (int i = 1; i <= NUM_LAB; i++) {
			asignaciones.put(i,  new TreeSet<>());
		}
	}
	
	public Asignaciones(int lab, String nFichero) throws FileNotFoundException {
		this(lab);
		leerPeticionesDesdeFichero(nFichero);
	}
	
	public void leerPeticionesDesdeFichero(String nFichero) throws FileNotFoundException {
		try (Scanner sc = new Scanner(new File(nFichero))) {
			while (sc.hasNextLine()) {
				realizarAsignacion(sc.nextLine());
			}
		}
	}
		
	public void realizarAsignacion(String linea) {	
		try (Scanner sc = new Scanner(linea)) {
			sc.useDelimiter("[#]");
			String na = sc.next();
			String np = sc.next();
			String dia = sc.next();
			String hora = sc.next();
			PeticionAsignacion pa = new PeticionAsignacion(np, na, new FranjaHoraria(dia, hora));						
			if (!nuevaAsignacion(pa)) {
				conflictos.add(pa);
			}		
		} catch (NoSuchElementException e) {
			throw new AsignacionException("Faltan datos ");
		}
	}
	
	
	
	public boolean nuevaAsignacion(PeticionAsignacion pa)  {
		boolean res = false;
		Set<Integer> huecos = buscarHuecos(pa.getFranja());
		if (!huecos.isEmpty()) {
			res = asignaciones.get(huecos.iterator().next()).add(pa);
		}
		return res;
	}
			
	public Set<Integer> buscarHuecos(FranjaHoraria fh) {
		PeticionAsignacion pa = new PeticionAsignacion("","", fh);
		Set<Integer> set = new HashSet<>();
		for (int i : asignaciones.keySet()) {
			if (!asignaciones.get(i).contains(pa)) {
				set.add(i);
			}
		}
		return set; 
	}

	@Override public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Asignacion de laboratorios\n");
		sb.append("--------------------------\n");
		for (int i : asignaciones.keySet()) {
			sb.append("Laboratorio " + i + "\n");
			for(PeticionAsignacion pa : asignaciones.get(i)) {
				sb.append("\t"+pa+"\n");
			}
		}
		sb.append("Conflictos\n");
		sb.append("----------\n");
		for(PeticionAsignacion pa: conflictos) {
			sb.append("\t"+pa+"\n");			
		}
		return sb.toString();
	}
	
	public void escribirAFichero(String nFichero) throws FileNotFoundException {
		try (PrintWriter pw = new PrintWriter(nFichero)) {
			escribirAsignaciones(pw);
		}
	}
	
	public void escribirAsignaciones(PrintWriter pw) {
		pw.println(this.toString());
	}
}
