package prExJunio2016;

public class AsignacionException extends RuntimeException  {
	public AsignacionException() {
		super();
	}
	
	public AsignacionException(String msg) {
		super(msg);
	}
}
