package prExJunio2016;

import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.Set;

public class AsignacionesConAlternativas extends Asignaciones {

	public AsignacionesConAlternativas(int lab, String nFichero) throws FileNotFoundException, AsignacionException {
		super(lab, nFichero);
	}

	@Override
	public void realizarAsignacion(String linea) {
			Set<PeticionAsignacion> set = leerAlternativas(linea);
			if (set.isEmpty()) {
				throw new AsignacionException("Linea incompleta " + linea);
			}
			Iterator<PeticionAsignacion> it = set.iterator();
			boolean asignada = false;
			PeticionAsignacion pa = null;
			while (it.hasNext() && !asignada) { 
				pa = it.next();
				asignada = nuevaAsignacion(pa);
			}		
			if (!asignada) {
				conflictos.add(pa);
			}
	}

	private Set<PeticionAsignacion> leerAlternativas(String linea) {
		Set<PeticionAsignacion> set = new HashSet<>();
		try (Scanner sc = new Scanner(linea)) {
			sc.useDelimiter("[#]");
			String na = sc.next();
			String np = sc.next();
			while (sc.hasNext()) { 
				String dia = sc.next();
				String hora = sc.next();
				set.add(new PeticionAsignacion(np, na, new FranjaHoraria(dia, hora)));						
			}
		} catch (NoSuchElementException e) {
			throw new AsignacionException("Faltan datos extras");
		}
		return set;
	}
}
