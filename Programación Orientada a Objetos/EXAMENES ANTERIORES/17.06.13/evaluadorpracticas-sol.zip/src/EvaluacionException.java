@SuppressWarnings("serial")
public class EvaluacionException extends RuntimeException {
	public EvaluacionException(String msg) {
		super(msg);
	}
	
	public EvaluacionException() {
		super();
	}
}