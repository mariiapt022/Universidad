package prExSept2016;

public class CompeticionException extends RuntimeException {
	public CompeticionException() {
		super();
	}
	public CompeticionException(String s) {
		super(s);
	}
}
