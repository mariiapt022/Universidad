
public class VideoclubException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public VideoclubException() {
		super();
	}
	
	public VideoclubException(String msg) {
		super(msg);
	}
	
}
