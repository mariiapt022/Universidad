package prMaternidad;

@SuppressWarnings("serial")
public class MaternidadException extends RuntimeException {
	public MaternidadException() {
		super();
	}
	
	public MaternidadException(String msg) {
		super(msg);
	}
}
