package prDocencia;

	@SuppressWarnings("serial")
	public class DocenciaException extends RuntimeException {
		public DocenciaException() {
			super();
		}
		
		public DocenciaException(String msg) {
			super(msg);
		}
	}



