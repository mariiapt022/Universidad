@SuppressWarnings("serial")
public class EurocopaException extends RuntimeException {
	public EurocopaException(String msg) {
		super(msg);
	}

	public EurocopaException() {
		super();
	}
}
