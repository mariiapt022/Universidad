package dhondt;
/**
 * La clase Divisor representa una asignaci�n de votos a un partido.
 */
public class Divisor implements Comparable<Divisor> {
	private String partido;
	private int votos;
	
	/**
	 * Construye instancias de Divisor con un partido y una proporci�n de votos.
	 * @param part	Nombre del partido 
	 * @param vs	N�mero de votos 
	 */
	public Divisor(String part, int vs) {
		partido = part;
		votos = vs;
	}
	
	/**
	 * Devuelve el partido del divisor
	 * @return	Partido
	 */
	public String getPartido() {
		return partido;
	}
	
	/**
	 * Dos divisores son iguales cuando coinciden el partido y el n�mero de votos.
	 */
	public boolean equals(Object otroDiv) {
		return otroDiv instanceof Divisor &&
		 	   ((Divisor) otroDiv).votos == votos &&
		 	   ((Divisor) otroDiv).partido.equalsIgnoreCase(partido);
	}
	
	/** 
	 * La funci�n hash del objeto debe ser consistente con equals.
	 */
	public int hashCode() {
		return votos + partido.toLowerCase().hashCode();
	}
	
	/**
	 * Un divisor es menor que otro cuando el n�mero de votos es mayor. En caso de 
	 * coincidir se considera el que sea menor alfab�ticamente. 
	 * En realidad, en caso de igualdad, el orden deber�a establecerse aleatoriamente, pero 
	 * consideramos el orden lexicogr�fico por simplicidad.
	 */
	public int compareTo(Divisor otroDiv) {
		int res = otroDiv.votos - votos;
		return res == 0 ? partido.compareToIgnoreCase(otroDiv.partido) : res; 
	}
	
	public String toString() {
		return partido + " --> " + votos;
	}
	
	
}
