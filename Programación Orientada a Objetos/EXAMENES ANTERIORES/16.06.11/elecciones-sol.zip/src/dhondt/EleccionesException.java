package dhondt;

public class EleccionesException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EleccionesException(String msg) {
		super(msg);
	}
}
