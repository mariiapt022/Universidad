import java.io.IOException;
import java.io.PrintWriter;

import dhondt.*;

public class PruebaElecciones {
	public static void main(String args[]) {
		try {
			EleccionesMunicipales em = new EleccionesMunicipales("eleccionesAndalucia.txt");
			em.print("resultados.txt");
			em.print(new PrintWriter(System.out,true));
		} catch (IOException ioe) {
			System.err.println("Error de E/S: " + ioe.getMessage());
		} catch (EleccionesException ee) {
			System.err.println(ee.getMessage());
		}
	}
}

