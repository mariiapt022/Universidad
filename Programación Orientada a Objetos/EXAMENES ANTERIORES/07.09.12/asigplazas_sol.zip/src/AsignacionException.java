
@SuppressWarnings("serial")
public class AsignacionException extends RuntimeException {
	public AsignacionException(String msg) {
		super(msg);
	}
	
	public AsignacionException() {
		super();
	}
}
